
public enum Direction {
    HORIZONTAL,
    VERTICAL
}