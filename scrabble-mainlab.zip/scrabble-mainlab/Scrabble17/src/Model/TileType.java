package Model;
public enum TileType {
    
    NORMAL,
    DOUBLE_LETTER,
    TRIPLE_LETTER,
    DOUBLE_WORD,
    TRIPLE_WORD,
    STAR_SPIN 

}
