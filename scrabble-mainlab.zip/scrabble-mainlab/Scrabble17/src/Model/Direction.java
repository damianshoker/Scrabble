package Model;

public enum Direction {
    HORIZONTAL,
    VERTICAL
}